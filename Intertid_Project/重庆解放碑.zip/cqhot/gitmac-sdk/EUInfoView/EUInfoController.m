//
//  EUInfoController.m
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-18.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUInfoController.h"
#import "EUAlertView.h"
#import "PTAPIEnc.h"
#import "NSURLRequestWithUID.h"
#import "EUZoomController.h"
#import "PTFixADViewController.h"
#import "PTPopupADViewController.h"
#import "PTDBMSManage.h"

#define NAVIGATOR_SHADOW_HIGHT 0
#define TOOLBAR_SHADOW_HEIGHT 15



typedef enum{
    EUInfoScreenFull,
    EUInfoScreenMid,
    EUInfoScreenAdMid,
    EUInfoScreenAdFull
}EUInfoScreen;


@interface EUInfoController ()
<UIWebViewDelegate,
UIGestureRecognizerDelegate,
PTFixADViewControllerDelegate,
PTPopupADViewControllerDelegate,
SYPaginatorViewDataSource,
SYPaginatorViewDelegate>

{
    BOOL isTouchImage;
    BOOL screenFill;
}


@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;
@property (assign, nonatomic) BOOL gestureTouchAtURL;
@property (strong, nonatomic) PTFixADViewController   *fixad;
@property (strong, nonatomic) PTPopupADViewController *popad;
@property (assign, nonatomic) BOOL fixadEnable;
@property (strong, nonatomic) UIView *adView;

@end

@implementation EUInfoController
@synthesize navigationBar = _navigationBar;
@synthesize toolBar       = _toolBar;

@synthesize infoItem  = _infoItem;
@synthesize itemsInfo = _itemsInfo;

@synthesize favoriteButton   = _favoriteButton;
@synthesize readModeButton   = _readModeButton;
@synthesize fontExpandButton = _fontExpandButton;
@synthesize fontReduceButton = _fontReduceButton;

@synthesize currentItemId = _currentItemId;

@synthesize infoMode = _infoMode;
@synthesize readMode = _readMode;
@synthesize fontSize = _fontSize;

@synthesize favorInfo = _favorInfo;

@synthesize shareToEmail  = _shareToEmail;
@synthesize shareToWeibo  = _shareToWeibo;
@synthesize shareToWeChat = _shareToWeChat;

@synthesize tapGesture = _tapGesture;
@synthesize gestureTouchAtURL = _gestureTouchAtURL;

@synthesize adView = _adView;
@synthesize popad  = _popad;
@synthesize fixad  = _fixad;

@synthesize fixadEnable = _fixadEnable;

@synthesize paginatorView = _paginator;
@synthesize pageWeb       = _pageWeb;

@synthesize euTip         = _euTip;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithMode:(EUInfoMode)infoMode {
    self = [super init];
    self.infoMode = infoMode;
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self dctInternal_setupInternals];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
  
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc
{

    self.fixad.delegate = nil;
    self.popad.delegate = nil;
    _paginator.dataSource = nil;
    _paginator.delegate = nil;
    EUSafeRelease(_paginator);
    EUSafeRelease(_paginator)
    EUSafeRelease(_toolBar)
    EUSafeRelease(_itemsInfo)
    EUSafeRelease(_infoItem)
    EUSafeRelease(_favoriteButton)
    EUSafeRelease(_readModeButton)
    EUSafeRelease(_shareToWeibo)
    EUSafeRelease(_navigationBar)
    EUSafeRelease(_shareToEmail)
    EUSafeRelease(_tapGesture)
    EUSafeRelease(_shareToWeChat)
    EUSafeRelease(_fixad)
    EUSafeRelease(_popad)
    EUSafeRelease(_adView)
    EUSafeRelease(_fontExpandButton)
    EUSafeRelease(_fontReduceButton)
    EUSuperDealoc
}

#pragma mark-
#pragma mark init
- (void)dctInternal_setupInternals
{
    
    self.navigationBar.title.text = self.title;
    self.view.backgroundColor = [UIColor colorWithWhite:.3 alpha:1];
    
    self.euTip = [EUTipView AnimationTipLoading:@"等待中..."];
    self.euTip.center = self.view.center;
    self.euTip.hidden = YES;
    [self.view addSubview:_euTip];
    
//    [self createFixAD];
//    if ([PTUtils fetchPopAdsStatus:[[self class] description]]) {
//        [self createPopAD];
//    }
  
    [self setupSYPage];
    
    if(_infoMode != EUInfoModePicture) {
        CGRect bounds = self.view.bounds;
        _paginator.frame = CGRectMake(bounds.origin.x,
                                      bounds.origin.y + _navigationBar.bounds.size.height,
                                      bounds.size.width,
                                      bounds.size.height - _navigationBar.bounds.size.height - _toolBar.bounds.size.height + shadow);
    }
    
   
}


#pragma mark -
#pragma mark IBAction

- (IBAction)backTo:(id)sender {
    if (isTouchImage) {
        isTouchImage = NO;
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)expandFontTo:(UIButton *)button {
    PTFontSize fontSize = [PTUtils fetchFontSize];
    switch (fontSize) {
        case PTFontSizeTiny:
            [PTUtils saveFontSize:PTFontSizeFit];
            break;
        case PTFontSizeFit:
            [PTUtils saveFontSize:PTFontSizeBig];
            break;
        case PTFontSizeBig:
//            [PTUtils saveFontSize:PTFontSizeTiny];
            break;
            
        default:
            break;
    }
    [self fontSizeToPreload];
}
- (IBAction)reduceFontTo:(UIButton *)button {
    PTFontSize fontSize = [PTUtils fetchFontSize];
    switch (fontSize) {
        case PTFontSizeTiny:
//            [PTUtils saveFontSize:PTFontSizeFit];
            break;
        case PTFontSizeFit:
            [PTUtils saveFontSize:PTFontSizeTiny];
            break;
        case PTFontSizeBig:
            [PTUtils saveFontSize:PTFontSizeFit];
            break;
        default:
            break;
    }
    [self fontSizeToPreload];
}

- (IBAction)fontSizeTo:(UIButton *)button {
    PTFontSize fontSize = [PTUtils fetchFontSize];
    switch (fontSize) {
        case PTFontSizeTiny:
            [PTUtils saveFontSize:PTFontSizeFit];
            break;
        case PTFontSizeFit:
            [PTUtils saveFontSize:PTFontSizeBig];
            break;
        case PTFontSizeBig:
            [PTUtils saveFontSize:PTFontSizeTiny];
            break;
            
        default:
            break;
    }
    [self fontSizeToPreload];
}
- (IBAction)readModeTo:(UIButton *)button {
    
    PTReadMode mode = [PTUtils fetchReadMode];
    switch (mode) {
        case PTReadModeDay:
            [PTUtils saveReadMode:PTReadModeNight];
            break;
        case PTReadModeNight:
            [PTUtils saveReadMode:PTReadModeDay];
            break;
            
        default:
            break;
    }
    
    [self readModeToPreload];
}
- (IBAction)shareTo:(UIButton *)button {


}

- (IBAction)downloadTo:(UIButton *)button {

}
- (IBAction)favoriteTo:(UIButton *)button {
    if ([PTUtils isFavorType:_infoMode dctInfo:_infoItem]) {
        [PTUtils deleteFavorType:_infoMode dctInfo:_infoItem];
        self.favorInfo = NO;
    }else {
        [PTUtils saveFavorType:_infoMode dctInfo:_infoItem];
    }
}

- (IBAction)prePage:(UIButton *)sender {
    NSInteger index = _paginator.currentPageIndex - 1;
    if (index >= 0) {
        [_paginator setCurrentPageIndex:index animated:YES];
    }
  
}
- (IBAction)nextPage:(UIButton *)sender {
    NSInteger index = _paginator.currentPageIndex + 1;
    if (index < [self.itemsInfo count]) {
        [_paginator setCurrentPageIndex:index animated:YES];
    }
}

#pragma mark -
#pragma mark EU

- (NSString*)shareIMGURL {
    NSString        *imageURL;
    NSMutableString *jsURL;
    
    
    //取超链接图
    jsURL = [NSString stringWithFormat:@"document.getElementsByTagName('a')[%d].href",0];
    imageURL = [self.pageWeb stringByEvaluatingJavaScriptFromString:jsURL];
    
    if ([imageURL length] > 0) {
        return imageURL;
    }
    
    //取环绕等图
    jsURL = [NSString stringWithFormat:@"document.getElementsByTagName('img')[%d].src",0];
    imageURL = [self.pageWeb stringByEvaluatingJavaScriptFromString:jsURL];
    
    if ([imageURL length] > 0) {
        int j = 0;
        while ([[[imageURL componentsSeparatedByString:@"/"] lastObject] isEqualToString:@"plug_iphone4.png"] ||
               [[[imageURL componentsSeparatedByString:@"/"] lastObject] isEqualToString:@"plug_iphone.png"]||
               [[[imageURL componentsSeparatedByString:@"/"] lastObject] isEqualToString:@"app_zaiyao.png"]) {
            jsURL = [NSString stringWithFormat:@"document.getElementsByTagName('img')[%d].src",j];
            imageURL = [self.pageWeb  stringByEvaluatingJavaScriptFromString:jsURL];
            j++;
        }
        return imageURL;
    }
    return nil;
    
    
}


- (PTShareToWeibo *)shareToWeibo
{
    return _shareToWeibo;
}

- (void)setShareToWeibo:(PTShareToWeibo *)shareToWeibo{
    if (_infoMode == EUInfoModeArticle) {
        if (shareToWeibo) {
            EUSafeRelease(_shareToWeibo)
            _shareToWeibo = shareToWeibo;
            _shareToWeibo.shareImageURL = [self shareIMGURL];
            _shareToWeibo.shareTitle = [self.pageWeb stringByEvaluatingJavaScriptFromString:@"document.title"];
            _shareToWeibo.shareAID = [self currentItemId];
            EURetain(_shareToWeibo)
        }
    }
    
    if (_infoMode == EUInfoModePicture) {
        if (shareToWeibo) {
            EUSafeRelease(_shareToWeibo)
            _shareToWeibo = shareToWeibo;
            _shareToWeibo.shareAID = [self currentItemId];
            EURetain(_shareToWeibo)
        }
    }
}

- (PTFontSize)fontSize {
    return [PTUtils fetchFontSize];
}

- (void)setFontSize:(PTFontSize)fontSize {
    [PTUtils saveReadMode:fontSize];
}

- (PTReadMode)readMode{
    return [PTUtils fetchReadMode];
}

- (void)setReadMode:(PTReadMode)readMode{
    [PTUtils saveReadMode:readMode];
}

- (void)setFavorInfo:(BOOL)favorInfo{
    _favorInfo = favorInfo;
}

- (BOOL)favorInfo{
    return [PTUtils isFavorType:_infoMode dctInfo:_infoItem];
}

- (NSString *)currentItemId
{
    return [_infoItem valueForKey:@"id"];
  
}


#pragma mark -
#pragma mark Hidden

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

- (void)tapGestureAction:(UITapGestureRecognizer*)gesture {
    
    
    NSLog(@"%d",gesture.numberOfTouchesRequired);
    switch (_infoMode) {
        case EUInfoModePicture:
            [self performSelector:@selector(barToHidden) withObject:self afterDelay:0];
            break;
        default:
             [self performSelector:@selector(barToHidden) withObject:self afterDelay:.6];
            break;
    }
   
}




- (void)barToHidden
{
    if (_infoMode != EUInfoModePicture) {
        if ([(SYPageWeb *)_paginator.currentPage surround]) {
            [(SYPageWeb *)_paginator.currentPage setSurround:NO];
            return;
        }
    }

    if (screenFill) {
        if (self.fixadEnable) {
            [self screenToUpate:EUInfoScreenAdMid];
        }else {
            [self screenToUpate:EUInfoScreenMid];
        }
       
    }else {
        if (self.fixadEnable) {
            [self screenToUpate:EUInfoScreenAdFull];
        }else {
            [self screenToUpate:EUInfoScreenFull];
        }
        
    }
}


#pragma mark -
#pragma mark ads
- (void)createPopAD {
    self.popad = [[PTPopupADViewController alloc] initWithParentView:self.view];
    self.popad.popAdPosition = PTAD_POPUP_FILE;
    self.popad.parentController = self.navigationController;
    self.popad.delegate = self;
    self.popad.userID = [PTUtils fetchConfig:kPTCONFIG_UID];
    self.popad.keywords = @"";
    [self.view addSubview:self.popad.view];
    [self.popad loadAd];
}

- (void)PopupADDidLoaded {
    [self.popad showAd];
    [PTUtils savePopAdsStatus:[[self class] description]];
}


- (void)createFixAD {
    self.fixadEnable = NO;
    self.fixad = [[[PTFixADViewController alloc] initWithFrame:CGRectMake(0, 0, 320, 48)] autorelease];
    for (UIView *view in [self.fixad.view subviews])
    {
        if ([[[view class] description] isEqualToString:@"UIADWebView"]) {
            UIADWebView *ad = (UIADWebView*)view;
            [[[ad subviews] lastObject] setScrollEnabled:NO];
        }
    }
    
    self.fixad.AdPosition = PTAD_FIX_FILE;
    self.fixad.delegate = self;
    self.fixad.userID = [PTUtils fetchConfig:kPTCONFIG_UID];
    self.fixad.keywords = @"";
    self.fixad.parentController = [[[UIApplication sharedApplication] delegate] window].rootViewController;
    [self.fixad loadAd];
}


- (void)FixADDidLoaded {
    self.fixadEnable = YES;
    if (_adView == nil) {
        self.adView = [[[UIView alloc] initWithFrame:CGRectMake(0, _navigationBar.bounds.size.height, 320, 48)] autorelease];
        [self.adView addSubview:self.fixad.view];
        [self.view addSubview:self.adView];
    }
    if (!screenFill) {
        [self screenDidUpate:[NSNumber numberWithInteger:EUInfoScreenAdMid]];
    }else {
         [self screenDidUpate:[NSNumber numberWithInteger:EUInfoScreenAdFull]];
    }
}

#pragma mark -
#pragma mark SYPageView

- (void)pageToUpdate {

}

- (void)pictureToUpdate {

}

- (UIWebView *)pageWeb {
    return [(SYPageWeb *)[_paginator currentPage] webView];
}

- (void)screenDidUpate:(NSNumber *)number {
    
    EUInfoScreen type = [number integerValue];
    CGRect  bounds = self.view.bounds;
    CGFloat shadow = NAVIGATOR_SHADOW_HIGHT + TOOLBAR_SHADOW_HEIGHT;
    CGRect  ad     = CGRectMake(0, 0, 320, 48);
    
    switch (type) {
        case EUInfoScreenAdFull:
            _adView.frame    = CGRectMake(0, 0, ad.size.width, ad.size.height);
            break;
        case EUInfoScreenAdMid:
            _adView.frame    = CGRectMake(0, _navigationBar.bounds.size.height, ad.size.width, ad.size.height);
            break;
        default:
            break;
    }
    
    if (_infoMode == EUInfoModePicture) {
        return;
    }

    
    
    switch (type) {
        case EUInfoScreenFull:
            _paginator.frame = self.view.bounds;
            break;
        case EUInfoScreenMid:
            _paginator.frame = CGRectMake(bounds.origin.x,
                                          bounds.origin.y + _navigationBar.bounds.size.height,
                                          bounds.size.width,
                                          bounds.size.height - _navigationBar.bounds.size.height - _toolBar.bounds.size.height + shadow);
            break;
        case EUInfoScreenAdFull:
            _paginator.frame = CGRectMake(bounds.origin.x, ad.size.height, bounds.size.width,bounds.size.height -  ad.size.height);
            break;
        case EUInfoScreenAdMid:
            _paginator.frame = CGRectMake(bounds.origin.x,
                                          _navigationBar.bounds.size.height + ad.size.height,
                                          bounds.size.width,
                                          bounds.size.height -  _navigationBar.bounds.size.height - ad.size.height - _toolBar.frame.size.height + shadow);
            break;
        default:
            break;
    }
    
}

- (void)animationDelay{
    CGFloat ty = _navigationBar.bounds.size.height;
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:.3];
    _navigationBar.transform = CGAffineTransformMakeTranslation(0, -ty);
    [UIView commitAnimations];
    
    ty = _toolBar.bounds.size.height;
    _toolBar.transform = CGAffineTransformMakeTranslation(0, 0);
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:.3];
    _toolBar.transform = CGAffineTransformMakeTranslation(0,ty);
    [UIView commitAnimations];
    
   
}

- (void)screenToUpate:(EUInfoScreen)type {
    
    CGRect  bounds = self.view.bounds;
    if (!screenFill) {
       
        if (_infoMode != EUInfoModePicture) {
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:.3];
            _paginator.frame = self.view.bounds;
            [UIView commitAnimations];
            [self performSelector:@selector(animationDelay) withObject:nil afterDelay:.1];
        }else {
            [self performSelector:@selector(animationDelay) withObject:nil afterDelay:0];
        }
       
      
        screenFill = YES;
    }else {
        CGFloat ty = _navigationBar.bounds.size.height;
        _navigationBar.transform = CGAffineTransformMakeTranslation(0, -ty);
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        _navigationBar.transform = CGAffineTransformMakeTranslation(0, 0);
        [UIView commitAnimations];
        
        ty = _toolBar.bounds.size.height;
        _toolBar.transform = CGAffineTransformMakeTranslation(0, ty);
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:.3];
        _toolBar.transform = CGAffineTransformMakeTranslation(0, 0);
        [UIView commitAnimations];
        
        
        if (_infoMode != EUInfoModePicture) {
            CGRect rect = _paginator.frame;
            
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:.3];
            rect.origin.y = bounds.origin.y + _navigationBar.bounds.size.height;
            _paginator.frame = rect;
            [UIView commitAnimations];
        }
     
        
        screenFill = NO;
        
    }
    [self performSelector:@selector(screenDidUpate:) withObject:[NSNumber numberWithInteger:type] afterDelay:.3];
}

- (void)fontSizeToPreload {
    
    NSInteger index = _paginator.currentPageIndex;
    UIWebView *webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
    [webView stringByEvaluatingJavaScriptFromString:[PTUtils fontSizeToString:[PTUtils fetchFontSize]]];
    
    
    int i = 0;
    while (--index >= 0 && i <= _paginator.numberOfPagesToPreload) {
        i++;
        webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
        [webView stringByEvaluatingJavaScriptFromString:[PTUtils fontSizeToString:[PTUtils fetchFontSize]]];
    }
    index = _paginator.currentPageIndex;
    while (++index <= _paginator.currentPageIndex + _paginator.numberOfPagesToPreload) {
        webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
        [webView stringByEvaluatingJavaScriptFromString:[PTUtils fontSizeToString:[PTUtils fetchFontSize]]];
    }
}

- (void)readModeToPreload {
    NSInteger index = _paginator.currentPageIndex;
    UIWebView *webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
    [webView stringByEvaluatingJavaScriptFromString:[PTUtils readModeToString:[PTUtils fetchReadMode]]];
    
    
    int i = 0;
    while (--index >= 0 && i <= _paginator.numberOfPagesToPreload) {
        i++;
         webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
        [webView stringByEvaluatingJavaScriptFromString:[PTUtils readModeToString:[PTUtils fetchReadMode]]];
    }
    index = _paginator.currentPageIndex;
    while (++index <= _paginator.currentPageIndex + _paginator.numberOfPagesToPreload) {
        webView = [(SYPageWeb *)[_paginator pageForIndex:index] webView];
        [webView stringByEvaluatingJavaScriptFromString:[PTUtils readModeToString:[PTUtils fetchReadMode]]];
    }
}


- (void)setupSYPage {
    
 
    _paginator = [[SYPaginatorView alloc] initWithFrame:self.view.bounds];
    _paginator.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _paginator.dataSource = self;
    _paginator.delegate   = self;
   
    [self.view addSubview:_paginator];
    [self.view sendSubviewToBack:_paginator];

    switch (_infoMode) {
        case EUInfoModePicture:
            NSLog(@"EUInfoModePicture");
            break;
            
        default:
            [_paginator setPageGapWidth:30.0f];
            [_paginator reloadData];
            [_paginator setCurrentPageIndex:[self.itemsInfo indexOfObject:self.infoItem] animated:NO];
            
            if ([PTUtils fetchReadMode] == PTReadModeNight) {
                self.pageWeb.hidden = YES;
            }
            break;
    }
   
    
    self.tapGesture = [[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)] autorelease];
    self.tapGesture.numberOfTapsRequired = 1;
    self.tapGesture.delegate = self;
    [_paginator addGestureRecognizer:self.tapGesture];
    
    self.gestureTouchAtURL = NO;
}

- (void)webToLoad:(SYPageWeb *)view {
    
    
    NSString *fontSize = nil;
    switch ([PTUtils fetchFontSize]) {
        case PTFontSizeBig:
            fontSize = @"b";
            break;
        case PTFontSizeFit:
            fontSize = @"m";
            break;
        case PTFontSizeTiny:
            fontSize = @"s";
            break;
        default:
            fontSize = @"m";
            break;
    }
    NSString *readMode = nil;
    switch ([PTUtils fetchReadMode]) {
        case PTReadModeDay:
            readMode = @"day";
            break;
        case PTReadModeNight:
            readMode = @"night";
            break;
        default:
            readMode = @"day";
            break;
    }
    if ([PTUtils fetchReadMode] == PTReadModeNight) {
        view.webView.backgroundColor    = [UIColor blackColor];
        if ([view.webView respondsToSelector:@selector(scrollView)]) {
            view.webView.scrollView.backgroundColor = [UIColor blackColor];
        }
        view.webView.hidden = YES;
//      view.webView.scalesPageToFit = YES;
    }
    
   
    
    NSString *url=[NSString stringWithFormat:@"http://test001.cqhot.com/demo/newsshow.php?id=%@",
                   [view.userInfo valueForKey:@"id"]];
//    PTArticleCache *ac = [[PTArticleCache alloc] init];
//    [NSURLCache setSharedURLCache:ac];                                               // 设置NSURL的共享缓存对象
//    NSData *cachedData = [PTArticleCache fetchCachedData:[NSURL URLWithString:url]]; // 获取URL的缓存
//  
//    if (cachedData) { // 有缓存
//        [view.webView loadData:cachedData
//                  MIMEType:@"text/html"
//          textEncodingName:@"utf-8"
//                   baseURL:[NSURL URLWithString:url]];
//    } else {          // 无缓存
//        [view.webView loadRequest:[NSURLRequestWithUID requestWithURL:[NSURL URLWithString:url]]];
//    }
//    
//    
//    EUSafeRelease(ac)
   [view.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];

}

- (void)zoomToLoad:(SYPageZoom *)pageZoom {
    EUZoomView *zoomView = pageZoom.zoomView;
    NSString *url = [NSString stringWithFormat:@"%@%@",[PTUtils fetchConfig:kPTCONFIG_CMS_DOMAIN],[pageZoom.userInfo valueForKey:@"icon"]];
    [zoomView.imageView setImageWithURL:[NSURL URLWithString:url] placeholderImage:nil options:EUImageProgressiveWhite];
}

#pragma mark -
#pragma mark SYPaginatorViewDelegate
- (NSInteger)numberOfPagesForPaginatorView:(SYPaginatorView *)paginator {
    return [_itemsInfo count];
}


- (SYPageView *)paginatorView:(SYPaginatorView *)paginator viewForPageAtIndex:(NSInteger)page {
    static NSString *identifier = @"identifier";
    
    if (_infoMode == EUInfoModePicture) {
        SYPageZoom *view = (SYPageZoom *)[paginator dequeueReusablePageWithIdentifier:identifier];
        if (!view) {
            view = [[SYPageZoom alloc] initWithReuseIdentifier:identifier];
        }
        view.userInfo = [_itemsInfo objectAtIndex:page];
        [self zoomToLoad:view];
        return view;

    }
    SYPageWeb *view = (SYPageWeb *)[paginator dequeueReusablePageWithIdentifier:identifier];
    if (!view) {
        view = [[SYPageWeb alloc] initWithReuseIdentifier:identifier];
    }
    view.viewController = self;
    view.userInfo = [_itemsInfo objectAtIndex:page];
    [self webToLoad:view];
    
    return view;
}

- (void)paginatorView:(SYPaginatorView *)paginatorView didScrollToPageAtIndex:(NSInteger)pageIndex {
    [[PTDBMSManage DBMSManage] endReadArticle];
    self.infoItem = [_itemsInfo objectAtIndex:pageIndex];
    PTArticleCache *ac = [[PTArticleCache alloc] init];
    [[PTDBMSManage DBMSManage] startReadArticle:[_infoItem valueForKey:@"id"]
                                       openMode:[ac valueForReadCache]?OPEN_MODE_CACHE:OPEN_MODE_CACHE];
    EUSafeRelease(ac);
    
    [self pageToUpdate];
    NSLog(@"%d",pageIndex);
}

@end
