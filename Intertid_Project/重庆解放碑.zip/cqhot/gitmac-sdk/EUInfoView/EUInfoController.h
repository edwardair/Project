//
//  EUInfoController.h
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-18.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUViewController.h"

#import "EULibraryCompat.h"

#import "PTUtils.h"
#import "PTArticleCache.h"
#import "PTShareToWeibo.h"
#import "PTShareToWeChat.h"
#import "EUShareToEmail.h"
#import "EUNavigationBar.h"
#import "EUToolBar.h"

#import "EUAnimation.h"

#import "SYPageView.h"
#import "SYPaginatorView.h"
#import "SYPageWeb.h"
#import "SYPageZoom.h"

// 主要用于图片和文章内页

@interface EUInfoController : UIViewController
{
    IBOutlet UIButton *_favoriteButton;
    IBOutlet UIButton *_readModeButton;
    
    IBOutlet UIButton *_fontExpandButton;
    IBOutlet UIButton *_fontReduceButton;
    
    IBOutlet EUToolBar  *_toolBar;
    IBOutlet EUNavigationBar  *_navigationBar;
 
}


- (id)initWithMode:(EUInfoMode)mode;
- (void)dctInternal_setupInternals;

@property (assign, nonatomic) EUInfoMode infoMode;
@property (assign, nonatomic) PTReadMode readMode;
@property (assign, nonatomic) PTFontSize fontSize;
@property (strong, nonatomic) PTShareToWeibo  *shareToWeibo;
@property (strong, nonatomic) PTShareToWeChat *shareToWeChat;
@property (strong, nonatomic) EUShareToEmail  *shareToEmail;
@property (assign, nonatomic) BOOL favorInfo;
// EU Property

@property (strong, nonatomic) NSDictionary *infoItem;
@property (strong, nonatomic) NSArray      *itemsInfo;

@property (strong, nonatomic) UIButton *favoriteButton;
@property (strong, nonatomic) UIButton *readModeButton;
@property (strong, nonatomic) UIButton *fontExpandButton;
@property (strong, nonatomic) UIButton *fontReduceButton;

@property (strong, nonatomic) EUNavigationBar *navigationBar;
@property (strong, nonatomic) EUToolBar       *toolBar;

@property (strong, nonatomic) EUTip *euTip;



// Article Info property
@property (strong, nonatomic) NSString  *currentItemId;
@property (strong, nonatomic) UIWebView *pageWeb;
@property (nonatomic, strong, readonly) SYPaginatorView *paginatorView;

- (IBAction)shareTo:(UIButton *)button;
- (IBAction)backTo:(UIButton *)sender;
- (IBAction)fontSizeTo:(UIButton *)button;
- (IBAction)readModeTo:(UIButton *)button;
- (IBAction)favoriteTo:(UIButton *)button;
- (IBAction)prePage:(UIButton *)sender;
- (IBAction)nextPage:(UIButton *)sender;
- (IBAction)expandFontTo:(UIButton *)button;
- (IBAction)reduceFontTo:(UIButton *)button;
- (IBAction)downloadTo:(UIButton *)button;

// Public Methods
- (void)barToHidden;     // 图片栏目继承
- (void)pageToUpdate;    // 当前页
- (void)pictureToUpdate; // 下一个图集


@end
