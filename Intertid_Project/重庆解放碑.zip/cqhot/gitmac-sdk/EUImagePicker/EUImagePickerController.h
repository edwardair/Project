//
//  EUImagePickerController.h
//  gitmac
//
//  Created by gitmac on 11/1/08.
//  Copyright 2008 gitmac. All rights reserved.
//

#import "EUKitCompat.h"


@interface EUImagePickerController : UIImagePickerController
{
	UIViewController *controller;
}


/**
	当自己消失的时候指向调用的controller执行方法
 */
@property(nonatomic,unsafe_unretained) UIViewController *controller;

/**
	临时图片，用于界面显示需要
 */
@property (strong, nonatomic) UIImage  *tempImage;


/**
	临时图片路径用于上传需要
 */
@property (strong, nonatomic) NSString *tempPath;


@end


@interface UIViewController(EUPicker)<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
/**
	Call the method when UIImagePickerController disapper.
	@param controller The EUImagePickerController(property: tempImage tempPath).
 */
- (void)imagePickerControllerDidDisappear:(EUImagePickerController *)controller;

/**
	UIViewController call UIImagePickerController take photo.
 */
- (void)takePicture;

@end
