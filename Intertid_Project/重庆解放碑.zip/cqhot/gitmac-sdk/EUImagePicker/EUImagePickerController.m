//
//  EUImagePickerController.m
//  TwitterFon
//
//  Created by kaz on 11/1/08.
//  Copyright 2008 naan studio. All rights reserved.
//


#import "EUImagePickerController.h"

@implementation EUImagePickerController
@synthesize controller = _controller;


- (void)viewDidDisappear:(BOOL)animated 
{
  [_controller imagePickerControllerDidDisappear:self];
	
}

- (void)dealloc {
  EUSafeRelease(_tempImage)
  EUSafeRelease(_tempPath)
  EUSuperDealoc
}
@end

@implementation UIViewController(EUPicker)


/**
	降低图片质量，以保证网络传输
	@param maxRelosution 图片质量参数 0.0-1.0
	@param image 图片
	@returns 变换后的图片
 */
- (UIImage*) scaleAndRotateImage:(float)maxRelosution image:(UIImage *)image

{
  CGImageRef imgRef = image.CGImage;
  
  CGFloat width  = CGImageGetWidth(imgRef);
  CGFloat height = CGImageGetHeight(imgRef);
  
  CGAffineTransform transform = CGAffineTransformIdentity;
  CGRect bounds = CGRectMake(0, 0, width, height);
  if (width > maxRelosution || height > maxRelosution) {
    CGFloat ratio = width/height;
    if (ratio > 1) {
      bounds.size.width  = maxRelosution;
      bounds.size.height = bounds.size.width / ratio;
    }
    else {
      bounds.size.height = maxRelosution;
      bounds.size.width  = bounds.size.height * ratio;
    }
  }
  
  CGFloat scaleRatio = bounds.size.width / width;
  CGSize imageSize   = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
  CGFloat boundHeight;
  UIImageOrientation orient = image.imageOrientation;
  switch(orient) {
      
    case UIImageOrientationUp: //EXIF = 1
      transform = CGAffineTransformIdentity;
      break;
      
    case UIImageOrientationUpMirrored: //EXIF = 2
      transform = CGAffineTransformMakeTranslation(imageSize.width, 0.0);
      transform = CGAffineTransformScale(transform, -1.0, 1.0);
      break;
      
    case UIImageOrientationDown: //EXIF = 3
      transform = CGAffineTransformMakeTranslation(imageSize.width, imageSize.height);
      transform = CGAffineTransformRotate(transform, M_PI);
      break;
      
    case UIImageOrientationDownMirrored: //EXIF = 4
      transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
      transform = CGAffineTransformScale(transform, 1.0, -1.0);
      break;
      
    case UIImageOrientationLeftMirrored: //EXIF = 5
      boundHeight = bounds.size.height;
      bounds.size.height = bounds.size.width;
      bounds.size.width = boundHeight;
      transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.width);
      transform = CGAffineTransformScale(transform, -1.0, 1.0);
      transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
      break;
      
    case UIImageOrientationLeft: //EXIF = 6
      boundHeight = bounds.size.height;
      bounds.size.height = bounds.size.width;
      bounds.size.width = boundHeight;
      transform = CGAffineTransformMakeTranslation(0.0, imageSize.width);
      transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
      break;
      
    case UIImageOrientationRightMirrored: //EXIF = 7
      boundHeight = bounds.size.height;
      bounds.size.height = bounds.size.width;
      bounds.size.width = boundHeight;
      transform = CGAffineTransformMakeScale(-1.0, 1.0);
      transform = CGAffineTransformRotate(transform, M_PI / 2.0);
      break;
      
    case UIImageOrientationRight: //EXIF = 8
      boundHeight = bounds.size.height;
      bounds.size.height = bounds.size.width;
      bounds.size.width = boundHeight;
      transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
      transform = CGAffineTransformRotate(transform, M_PI / 2.0);
      break;
      
    default:
      [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
      
  }
  
  UIGraphicsBeginImageContext(bounds.size);
  
  CGContextRef context = UIGraphicsGetCurrentContext();
  
  if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
    CGContextScaleCTM(context, -scaleRatio, scaleRatio);
    CGContextTranslateCTM(context, -height, 0);
  }
  else {
    CGContextScaleCTM(context, scaleRatio, -scaleRatio);
    CGContextTranslateCTM(context, 0, -height);
  }
  
  CGContextConcatCTM(context, transform);
  
  CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
  UIImage *imageCopy = UIGraphicsGetImageFromCurrentImageContext();
  UIGraphicsEndImageContext();
  
  return imageCopy;
}

/**
	图片处理函数
	@param _image 待处理的图片
	@returns 处理后存放的文件路径，在网络上传中需要的路径
 */
- (NSString *)processPhoto:(UIImage *)_image
{
  float width  = _image.size.width;
  float height = _image.size.height;
  float scale;
  
  if (width > height) {
    scale = 320.0 / width;
  }
  else {
    scale = 480.0 / height;
  }
  
  NSData *imageData = nil;
  if (scale >= 1.0) {
    imageData = UIImageJPEGRepresentation(_image, 0.6);
  }
  else if (scale < 1.0) {
    imageData = UIImageJPEGRepresentation([self scaleAndRotateImage:480 image:_image], 0.6);
  }
  
  NSString *homePath          = NSHomeDirectory();
  NSString *folderPath        = [homePath stringByAppendingPathComponent:@"Library/Caches/Temp"];
  NSFileManager *fileManager  = [NSFileManager defaultManager];
  
  if (![fileManager fileExistsAtPath:folderPath]) {
    [fileManager createDirectoryAtPath:folderPath withIntermediateDirectories:YES attributes:nil error:nil];
  }
  NSString *fileName = [NSString stringWithFormat:@"Library/Caches/Temp/%@",@"newsimage.png"];
  NSString *filePath = [homePath stringByAppendingPathComponent:fileName];
  
  [imageData writeToFile:filePath atomically:YES];
  
  return filePath;
}




#pragma mark -
#pragma mark Interface Methods

- (void)takePicture{
  
  NSString *homePath = NSHomeDirectory();
  NSString *fileName = [NSString stringWithFormat:@"Library/Caches/Temp/newsimage.png"];
  NSString *filePath = [homePath stringByAppendingPathComponent:fileName];
  NSFileManager *fm  = [NSFileManager defaultManager];
  
  if ([fm fileExistsAtPath:filePath]) {
    [fm removeItemAtPath:filePath error:nil];
  }
  
  BOOL hasCamera = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
  
  if (hasCamera == false) {
    [self showImagePicker:false];
    return;
  }
  
  UIActionSheet *as = [[UIActionSheet alloc] initWithTitle:nil
                                                  delegate:self
                                         cancelButtonTitle:nil
                                    destructiveButtonTitle:nil
                                         otherButtonTitles:nil];
  
  [as addButtonWithTitle:@"从相册上传"];
  if (hasCamera) {
    [as addButtonWithTitle:@"拍照上传"];
  }
  [as addButtonWithTitle:@"取消"];
  as.cancelButtonIndex = [as numberOfButtons] - 1;
  
  [as showInView:self.view];
  EUSafeRelease(as)
  
}

- (void)showImagePicker:(BOOL)hasCamera
{
  EUImagePickerController *picker = [[EUImagePickerController alloc] init];
  picker.controller               = self;
  picker.delegate                 = self;
  
  if (hasCamera) {
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
  }
  [self.navigationController presentModalViewController:picker animated:YES];
  EUSafeRelease(picker)
}


#pragma mark -
#pragma mark UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
  
  if (actionSheet.cancelButtonIndex == buttonIndex) {
    return;
  }
  
  NSString *title = [actionSheet buttonTitleAtIndex:buttonIndex];
  if ([title isEqualToString:@"拍照上传"]) {
    [self showImagePicker:true];
  }
  else {
    [self showImagePicker:false];
  }
}



#pragma mark -
#pragma mark UIImagePickerDelegate


- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
  // do nothing here
}

- (void)imagePickerController:(EUImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
  
  [picker dismissModalViewControllerAnimated:true];
  if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
    UIImageWriteToSavedPhotosAlbum([info valueForKey:UIImagePickerControllerOriginalImage],
                                   self,
                                   @selector(image:didFinishSavingWithError:contextInfo:),
                                   nil);
  }
  
  picker.tempImage = [info valueForKey:UIImagePickerControllerOriginalImage];
  picker.tempPath  = [self processPhoto:picker.tempImage];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
  [picker dismissModalViewControllerAnimated:YES];
}


- (void)imagePickerControllerDidDisappear:(EUImagePickerController *)controller {
  
}


@end
