//
//  EUGridViewCell.m
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-17.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUGridViewCell.h"
#import "EULibraryCompat.h"

@implementation EUGridViewCell
@synthesize selected,highlighted,index,delegate;
@synthesize titleLabel = _titleLabel;
@synthesize imageView = _imageView;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)dealloc
{
    EUSafeRelease(_titleLabel)
    EUSafeRelease(_imageView)
    EUSuperDealoc
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)changehighlighted{
    self.highlighted = NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    self.highlighted = YES;
    [super touchesEnded:touches withEvent:event];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event {
    self.highlighted = NO;
    [super touchesCancelled:touches withEvent:event];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [self performSelector:@selector(changehighlighted) withObject:self afterDelay:.3];
    [self.delegate gridViewCellWasTouched:self];
    [super touchesEnded:touches withEvent:event];
}



@end
