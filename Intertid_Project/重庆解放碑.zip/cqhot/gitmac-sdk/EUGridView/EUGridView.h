//
//  EUGridView.h
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-17.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EUGridViewCell.h"

@protocol EUGridViewDelegate;
@protocol EUGridViewDataSource;
@interface EUGridView : NSObject<EUGridViewCellDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (assign, nonatomic) IBOutlet id<EUGridViewDataSource> dataSource;
@property (strong, nonatomic) IBOutlet id<EUGridViewDelegate> delegate;

- (void)reloadData;
- (EUGridViewCell *)cellForIndex:(NSInteger)aIndex;
@end


@protocol EUGridViewDelegate <NSObject>


- (void)gridView:(EUGridView *)gridView didSelectIndex:(NSInteger)index;

@end

@protocol EUGridViewDataSource <NSObject>

- (EUGridViewCell *)gridView:(EUGridView *)gridView cellForIndex:(NSInteger )index;
- (NSInteger)numberOfItemsInGridView:(EUGridView *)gridView;
- (CGSize)sizeOfItemInGridView:(EUGridView *)gridView;

@end