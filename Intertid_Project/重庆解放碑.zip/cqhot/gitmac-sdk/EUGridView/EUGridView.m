//
//  EUGridView.m
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-17.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUGridView.h"
#import "EULibraryCompat.h"

#define ROW_ITEMS 2


#define TOP_MARGIN      8
#define BOTTOM_MARGIN   0
#define LEFT_MARGIN     20
#define CENTER_SPACE    22
#define RIGHT_MARGIN    22

@interface EUGridView() <UITableViewDataSource,UITableViewDelegate>



@property (strong, nonatomic) NSMutableDictionary *visibleCells;

@property (assign, nonatomic) NSInteger count;
@end

@implementation EUGridView
@synthesize tableView = _tableView;
@synthesize delegate = _delegate;
@synthesize dataSource = _dataSource;
@synthesize visibleCells = _visibleCells;
@synthesize count = _count;


- (void)dealloc
{

    EUSafeRelease(_tableView)
    EUSafeRelease(_visibleCells)
    EUSuperDealoc
}

- (id)init
{
    self = [super init];
    [self setup];
    return self;
}

- (void)setup {
    self.visibleCells = [[[NSMutableDictionary alloc] init] autorelease];
}
- (void)reloadData {
    [_tableView reloadData];
}
- (EUGridViewCell *)cellForIndex:(NSInteger)aIndex {
    EUGridViewCell *cell = [_visibleCells objectForKey:[NSNumber numberWithInteger:aIndex]];
    return cell;
}



- (NSInteger)count {
    _count =  [_dataSource numberOfItemsInGridView:self];
    return _count;
}
#pragma mark -
#pragma mark 

- (NSInteger)row
{
    NSInteger count = self.count;
    BOOL spaceLine = count % ROW_ITEMS == 0?YES:NO;
    if (spaceLine) {
        return count/ROW_ITEMS;
    }else{
        return count/ROW_ITEMS + 1;
    }
}


- (CGFloat)rowHeight
{
    CGSize size = [_dataSource sizeOfItemInGridView:self];
    return size.height + BOTTOM_MARGIN + TOP_MARGIN;
}

- (CGRect)CGRectIndexPath:(NSIndexPath *)indexPath withColumn:(NSInteger)column{
    CGSize size = [_dataSource sizeOfItemInGridView:self];
    
    CGRect rect;
    if (column == 0) {
        rect.origin.x = LEFT_MARGIN;
        rect.origin.y = TOP_MARGIN;
        rect.size = size;
    }else if(column == 1) {
        rect.origin.x = LEFT_MARGIN + size.width + CENTER_SPACE;
        rect.origin.y = TOP_MARGIN;
        rect.size = size;
    }
    return rect;
}


#pragma mark -
#pragma mark UITableViewDelegate




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self row];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self rowHeight];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier:@"indexPath"] autorelease];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    [[cell subviews] makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    for (int i = 0; i < ROW_ITEMS; i++) {
        NSInteger aIndex = indexPath.row * 2 + i;
        if (aIndex < self.count) {
            EUGridViewCell *gridCell = [_dataSource gridView:self cellForIndex:aIndex];
            gridCell.index = aIndex;
            gridCell.delegate = self;
            [gridCell setFrame:[self CGRectIndexPath:indexPath withColumn:i]];
            [cell addSubview:gridCell];
            
            [_visibleCells setObject:gridCell forKey:[NSNumber numberWithInteger:aIndex]];
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    for (int i = 0; i < ROW_ITEMS; i++) {
        NSInteger aIndex = indexPath.row * 2 + i;
        [_visibleCells removeObjectForKey:[NSNumber numberWithInteger:aIndex]];
    
    }
}

- (void)gridViewCellWasTouched:(EUGridViewCell *)gridViewCell
{
    [_delegate gridView:self didSelectIndex:gridViewCell.index];
}

@end
