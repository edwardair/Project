//
//  EUGridViewCell.h
//  AgencyOutlook
//
//  Created by zeng liang on 12-10-17.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EUGridViewCellDelegate;
@interface EUGridViewCell : UIView


@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UIImageView *imageView;


@property (assign, nonatomic) id<EUGridViewCellDelegate>delegate;
@property (nonatomic, assign) BOOL selected;
@property (nonatomic, assign) BOOL highlighted;
@property (assign, nonatomic) NSUInteger index;
@end

@protocol EUGridViewCellDelegate <NSObject>

- (void)gridViewCellWasTouched:(EUGridViewCell *)gridViewCell;

@end

