//
//  EUAd.h
//  AgencyOutlook
//
//  Created by palmtrends on 12-11-14.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PTFixADViewController.h"
#import "PTPopupADViewController.h"

#define AD_HEIGHT 48
#define HD_HEIGHT 150

@interface EUAd : NSObject

@end

@interface UITableView (Ad)<PTFixADViewControllerDelegate>

@property (strong, nonatomic) UIView *adView;
@property (strong, nonatomic) PTFixADViewController *fixad;

- (void)createFixAD:(PTAD_TYPE_POSITION)position;
@end


@interface UIViewController(Ad)<PTPopupADViewControllerDelegate>

@property (strong, nonatomic) PTPopupADViewController *popad;
- (void)createPopAD:(PTAD_TYPE_POSITION)position;
- (void)destroyPopAD;
@end