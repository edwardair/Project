//
//  EUAd.m
//  AgencyOutlook
//
//  Created by palmtrends on 12-11-14.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUAd.h"
#import "EULibraryCompat.h"
#import "PTUtils.h"

#import <objc/runtime.h>



@implementation EUAd


@end




static char UITableViewAd;
static char UITableViewFixAd;

@implementation UITableView(Ad)
@dynamic fixad;
@dynamic adView;

- (void)setFixad:(PTFixADViewController *)fixad {
    objc_setAssociatedObject(self, &UITableViewFixAd,fixad,OBJC_ASSOCIATION_RETAIN);
}

- (PTFixADViewController *)fixad {
    PTFixADViewController *fixad = objc_getAssociatedObject(self, &UITableViewFixAd);
    if (!fixad) {
        fixad = EUReturnAutoreleased([[PTFixADViewController alloc] initWithFrame:CGRectMake(0, 0, 320, AD_HEIGHT)]);
        self.fixad = fixad;
    }
    return fixad;
}

- (void)setAdView:(UIView *)adView {
     objc_setAssociatedObject(self, &UITableViewAd,adView,OBJC_ASSOCIATION_RETAIN);
}

- (UIView *)adView {
    UIView *adView = objc_getAssociatedObject(self, &UITableViewAd);
    if (!adView) {
        adView = EUReturnAutoreleased([[UIView alloc] initWithFrame:CGRectMake(0, HD_HEIGHT, 320, AD_HEIGHT)]);
        [adView addSubview:self.fixad.view];
        self.adView = adView;
    }
    return adView;
}



- (void)createFixAD:(PTAD_TYPE_POSITION)position {
    
    for (UIView *view in [self.fixad.view subviews])
        {
            if ([[[view class] description] isEqualToString:@"UIADWebView"]) {
                UIADWebView *ad = (UIADWebView*)view;
                [[[ad subviews] lastObject] setScrollEnabled:NO];
            }
        }

    self.fixad.AdPosition = PTAD_FIX_IN_LIST;
    self.fixad.delegate = self;
    self.fixad.userID = [PTUtils fetchConfig:kPTCONFIG_UID];
    self.fixad.keywords = @"";
    self.fixad.parentController = [[[UIApplication sharedApplication] delegate] window].rootViewController;
    [self.fixad loadAd];
}


- (void)FixADDidLoaded {
    
    if (self.tableHeaderView == nil) {
        self.tableHeaderView = self.fixad.view;
        return;
        
    }
    for (UIView * view in self.tableHeaderView.subviews)
        view.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin|UIViewAutoresizingFlexibleLeftMargin;
    UIView *view = self.tableHeaderView;
    [self.tableHeaderView addSubview:self.adView];
    self.tableHeaderView.frame = CGRectMake(0, 0, 320, HD_HEIGHT+AD_HEIGHT);
    self.tableHeaderView = view;
  
}


@end


static char UIViewPopAd;
@implementation UIViewController(Ad)
@dynamic popad;

- (void)setPopad:(PTPopupADViewController *)popad {
    objc_setAssociatedObject(self, &UIViewPopAd,popad,OBJC_ASSOCIATION_RETAIN);
}

- (PTPopupADViewController *)popad {
    PTPopupADViewController *popad = objc_getAssociatedObject(self, &UIViewPopAd);
    if (!popad) {
        popad = [[PTPopupADViewController alloc] initWithParentView:self.view];
        self.popad = popad;
    }
    return popad;
}

- (void)destroyPopAD {
//    [self.popad performSelector:@selector(viewWillDisappear:) withObject:nil];
    objc_setAssociatedObject(self, &UIViewPopAd,nil,OBJC_ASSOCIATION_ASSIGN);
}

- (void)createPopAD:(PTAD_TYPE_POSITION)position {
  
  return;
    if ([PTUtils fetchPopAdsStatus:[[self class] description]]) {
        self.popad = [[PTPopupADViewController alloc] initWithParentView:self.view];
        self.popad.popAdPosition = position;
        self.popad.parentController = self.navigationController;
        self.popad.delegate = self;
        self.popad.userID = [PTUtils fetchConfig:kPTCONFIG_UID];
        self.popad.keywords = @"";
        [self.view addSubview:self.popad.view];
        [self.popad loadAd];
    }
   
}


- (void)PopupADDidLoaded {
    [self.popad showAd];
    [PTUtils savePopAdsStatus:[[self class] description]];
}

@end