//
//  EUImageDownloader.m
//  Demo_1
//
//  Created by zeng liang on 12-10-13.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUImageManager.h"
#import "ASIHTTPRequest.h"
#import "ASINetworkQueue.h"
#import "EUImageCache.h"
#import "EUImagePath.h"


static EUImageManager *imageManager = nil;
@interface EUImageManager() <ASIHTTPRequestDelegate>
{
    
    NSMutableArray *managerRequests;
    NSMutableArray *managerDelegates;
    NSMutableDictionary *managerReqForURL;
}

@end

@implementation EUImageManager
@synthesize delegate = _delegate;

- (void)dealloc
{
    EUSafeRelease(managerDelegates);
    EUSafeRelease(managerDelegates);
    EUSafeRelease(managerReqForURL);
    EUSuperDealoc;
}

#pragma mark -
#pragma mark 

+ (id)shareManager {
    if(!imageManager) {
        imageManager = [[EUImageManager alloc] init];
    }
    return imageManager;
}

- (id)init
{
    self = [super init];
    if (self) {
        managerDelegates = [[NSMutableArray alloc] init];
        managerRequests  = [[NSMutableArray alloc] init];
        managerReqForURL = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void)downloadWithURL:(NSURL *)url delegate:(id<EUImageManagerDelegate>)delegate {
   
    ASIHTTPRequest *request = [managerReqForURL objectForKey:url];
    if (request == nil) {
        request = [ASIHTTPRequest requestWithURL:url];
        request.delegate = self;
        request.userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
                            delegate,@"delegate",
                            url,@"url", nil];
        [managerReqForURL setObject:request forKey:url];
        [request performSelectorOnMainThread:@selector(startAsynchronous) withObject:nil waitUntilDone:YES];
    }
    
    [self setDelegate:delegate];
    [managerRequests addObject:request];
    [managerDelegates addObject:delegate];
    
   
    
    
}
- (void)cancelForDelegate:(id<EUImageManagerDelegate>)delegate {
    NSUInteger idx;
    while ((idx = [managerDelegates indexOfObjectIdenticalTo:delegate]) != NSNotFound){
        
        NSLog(@"managerDelegates:%@",[managerDelegates description]);
        NSLog(@"managerRequests:%@",[managerRequests description]);
        NSLog(@"managerReqForURL:%@",[managerReqForURL description]);

        
        [managerDelegates removeObjectAtIndex:idx];
        
        ASIHTTPRequest *request = [managerRequests objectAtIndex:idx];
        
        if ([managerRequests containsObject:request]) {
            [request clearDelegatesAndCancel];
            [managerRequests removeObjectAtIndex:idx];
//            [managerReqForURL removeObjectForKey:request.url];
        }
        if ([managerReqForURL objectForKey:request.url]) {
            [managerReqForURL removeObjectForKey:request.url];
        }
       
            
    }
}

#pragma mark -

- (void)requestFailed:(ASIHTTPRequest *)request {
    EURetain(request);
  
    for (NSInteger idx = (NSInteger)[managerRequests count] - 1; idx >= 0; idx--)
    {
        NSUInteger uidx = (NSUInteger)idx;
        ASIHTTPRequest *aRequest = [managerRequests objectAtIndex:uidx];
        if (aRequest == request)
        {
            id<EUImageManagerDelegate> delegate = [managerDelegates objectAtIndex:uidx];
            EURetain(delegate);
            EUAutorelease(delegate);
            
            if (delegate && [delegate respondsToSelector:@selector(imageManager:didFailWithError:)]) {
                [delegate performSelector:@selector(imageManager:didFailWithError:) withObject:self withObject:request.error];
            }
            
            
            [managerRequests removeObjectAtIndex:uidx];
            [managerDelegates removeObjectAtIndex:uidx];
            }
        }
    
    // Release the request
    [managerReqForURL removeObjectForKey:request.url];
    [request clearDelegatesAndCancel];
    
    EURelease(request);

}

- (void)requestStarted:(ASIHTTPRequest *)request
{
//    NSLog(@"%@",[request.url absoluteString]);
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
//    NSLog(@"%@",request.responseData);

    EURetain(request);
    
    UIImage *image = EUScaledImageForPath(request.url.absoluteString, request.responseData);
    for (NSInteger idx = (NSInteger)[managerRequests count] - 1; idx >= 0; idx--)
    {
        NSUInteger uidx = (NSUInteger)idx;
        ASIHTTPRequest *aRequest = [managerRequests objectAtIndex:uidx];
        if (aRequest == request)
        {
            id<EUImageManagerDelegate> delegate = [managerDelegates objectAtIndex:uidx];
            EURetain(delegate);
            EUAutorelease(delegate);
            
            if (image)
            {
                if (delegate && [delegate respondsToSelector:@selector(imageManager:didFinishWithImage:)]) {
                    [delegate performSelector:@selector(imageManager:didFinishWithImage:) withObject:self withObject:image];
                }
            }else {
                if (delegate && [delegate respondsToSelector:@selector(imageManager:didFailWithError:)]) {
                    [delegate performSelector:@selector(imageManager:didFailWithError:) withObject:self withObject:request.error];
                }
            }
            
            
            [managerRequests removeObjectAtIndex:uidx];
            [managerDelegates removeObjectAtIndex:uidx];
            }
        }
    
    if (image)
        {
        // Store the image in the cache
        [[EUImageCache sharedImageCache] storeImage:image
                                          imageData:request.responseData
                                             forKey:request.url.absoluteString
                                             toDisk:YES];
        }
    
    // Release the downloader
    [managerReqForURL removeObjectForKey:request.url];
    [request clearDelegatesAndCancel];
    
    EURelease(request);
}



@end
