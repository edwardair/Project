//
//  EUCache.m
//  Demo_1
//
//  Created by zeng liang on 12-10-13.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import "EUCache.h"
#import "Reachability.h"


@implementation EUCache

@end

@implementation UIImageView(EU)

- (void)setImageWithURL:(NSURL *)url {
    [self setImageWithURL:url placeholderImage:nil];
}
- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder {
    [self setImageWithURL:url placeholderImage:placeholder options:0];
}
- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder options:(EUImageOptions)option {
    
    NSLog(@"%@",url.absoluteString);
    
    UIImage *image = [[EUImageCache sharedImageCache] imageFromKey:url.absoluteString];
    self.image = placeholder;
    if (!image) {
        
        if ([[[url.absoluteString componentsSeparatedByString:@"."] lastObject] isEqualToString:@"jpg"] ||
            [[[url.absoluteString componentsSeparatedByString:@"."] lastObject] isEqualToString:@"png"] ||
            [[[url.absoluteString componentsSeparatedByString:@"/"] lastObject] isEqualToString:@"1"]) {
        
            if (option & EUImageProgressiveDownload || option & EUImageProgressiveWhite) {
                UIActivityIndicatorView *indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                if (option & EUImageProgressiveWhite) {
                    indicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
                }
                CGPoint center = CGPointMake(self.bounds.size.width/2.0,self.bounds.size.height/2.0);
                [indicator setCenter:center];
                [indicator startAnimating];
                [self addSubview:indicator];
                EUSafeRelease(indicator);
            }
            [[EUImageManager shareManager] cancelForDelegate:self];
            [[EUImageManager shareManager] downloadWithURL:url delegate:self];
        }

    }else {
        self.image = image;
    }
}


- (void)imageManager:(EUImageManager *)downloader didFinishWithImage:(UIImage *)image{
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
            [view removeFromSuperview];
        }
    }
    self.image = image;
    [self setNeedsLayout];
}
- (void)imageManager:(EUImageManager *)downloader didFailWithError:(NSError *)error {
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIActivityIndicatorView class]]) {
            [view removeFromSuperview];
        }
    }
}


- (void)removeFromSuperview {
    [super removeFromSuperview];
    [[EUImageManager shareManager] cancelForDelegate:self];
   
}
- (void)dealloc
{
    EUSuperDealoc;
}
@end