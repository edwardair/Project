//
//  EUImageDownloader.h
//  Demo_1
//
//  Created by zeng liang on 12-10-13.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "EUKitCompat.h"


@protocol EUImageManagerDelegate;
@interface EUImageManager : NSObject

@property (assign, nonatomic) id<EUImageManagerDelegate> delegate;


+ (id)shareManager;
- (void)downloadWithURL:(NSURL *)url delegate:(id<EUImageManagerDelegate>)delegate;
- (void)cancelForDelegate:(id<EUImageManagerDelegate>)delegate;
@end


@protocol EUImageManagerDelegate <NSObject>

@optional
- (void)imageManager:(EUImageManager *)downloader didFinishWithImage:(UIImage *)image;
- (void)imageManager:(EUImageManager *)downloader didFailWithError:(NSError *)error;
@end