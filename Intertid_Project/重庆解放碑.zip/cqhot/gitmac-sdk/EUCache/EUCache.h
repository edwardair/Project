//
//  EUCache.h
//  Demo_1
//
//  Created by zeng liang on 12-10-13.
//  Copyright (c) 2012年 zeng liang. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "EUImageCache.h"
#import "EUImageManager.h"
#import "EUKitCompat.h"



@interface EUCache : NSObject


@end


typedef enum
{
    EUImageRetryFailed = 1 << 0,
    EUImageProgressiveDownload = 1 << 1,
    EUImageProgressiveWhite = 1 << 2,
}EUImageOptions;

@interface UIImageView(EU)<EUImageManagerDelegate>

- (void)setImageWithURL:(NSURL *)url;
- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder;
- (void)setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder options:(EUImageOptions)option;

@end