//
//  EUFunc.h
//  
//
//  Created by zeng liang on 12-10-11.
//
//

#import <Foundation/Foundation.h>
#import "EUKitCompat.h"

@interface EUFunc : NSObject
+ (BOOL)validateMobileNumber:(NSString *)mobileNum;

+ (BOOL)validateEmailAddress:(NSString *)aAddress;

+ (BOOL)validateImageURL:(NSURL *)URL;

+ (BOOL)validateName:(NSString *)name;

+ (BOOL)validateContent:(NSString *)content;

+ (BOOL)validateNSString:(id)temp;

+ (NSString *)dateToString:(NSDate *)date;
+ (NSDate *)stringToDate:(NSString *)string;

+ (NSString *)MD5Func:(NSString *)key;
+ (NSString *)md5URL:(NSURL*)url;

+ (NSString *)USDateToCNDate:(NSString *)dateString;
+ (NSString *)formatDate:(NSString *)date;


+ (NSInteger)weiBoCountLimitString:(NSString *)string;


// 方法1：使用NSFileManager来实现获取文件大小
+ (long long) fileSizeAtPath1:(NSString*) filePath;
// 方法1：使用unix c函数来实现获取文件大小
+ (long long) fileSizeAtPath2:(NSString*) filePath;


// 方法1：循环调用fileSizeAtPath1
+ (long long) folderSizeAtPath1:(NSString*) folderPath;
// 方法2：循环调用fileSizeAtPath2
+ (long long) folderSizeAtPath2:(NSString*) folderPath;
// 方法2：在folderSizeAtPath2基础之上，去除文件路径相关的字符串拼接工作
+ (long long) folderSizeAtPath3:(NSString*) folderPath;

+ (NSString *)delNonCh:(NSString*)str ;


@end


@interface UIColor (EURGB)

/**
 * 通过字符串产生UIColor
 * @param string eg:120,120,120 rgb image.png/image.jpg img color
 */
+ (UIColor*)colorWithRGBString:(NSString*)string;


@end

@interface NSString(CGSIZE)

- (CGFloat)stringWithFont:(UIFont *)font constrainedToWidth:(CGFloat)width;
- (CGFloat)stringWithFont:(UIFont *)font constrainedToHeight:(CGFloat)height;
- (NSString *)stringByRemovingControlCharacters;

@end

@interface UIImage (UIImageUtils)		//为image类中增加函数
- (UIImage*)scaleAndRotateImage:(float)maxResolution;
- (UIImage*)scaleToSize:(NSInteger)newSize;
@end

