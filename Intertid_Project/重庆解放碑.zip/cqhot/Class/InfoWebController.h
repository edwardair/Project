//
//  InfoWebController.h
//  仅有UIWebView浏览的控制器
//
//  Created by ZL on 13-4-7.
//  Copyright (c) 2013年 gitmac. All rights reserved.
//

#import "EUViewController.h"

@interface InfoWebController : EUViewController


@property (strong, nonatomic) NSURL *webURL;
@end
