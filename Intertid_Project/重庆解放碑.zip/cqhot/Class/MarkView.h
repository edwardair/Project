//
//  MarkView.h
//  cqhot
//
//  Created by ZL on 13-4-11.
//  Copyright (c) 2013年 gitmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MarkView : UIView


/**
	标注几星:1-5
 */
@property (assign, nonatomic) NSInteger star;
@end
