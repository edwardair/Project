//
//  ConfigureController.h
//  cqhot
//
//  Created by ZL on 13-4-2.
//  Copyright (c) 2013年 gitmac. All rights reserved.
//

#import "EUViewController.h"

@interface ConfigureController : EUViewController

@end
