//
//  RouteView.h
//  cqhot
//
//  Created by ZL on 4/24/13.
//  Copyright (c) 2013 gitmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RouteView : UIView


@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
