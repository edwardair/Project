//
//  NavigationController.h
//  hmHospital
//
//  Created by ZL on 13-3-18.
//  Copyright (c) 2013年 Gitmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationController : UINavigationController

@end
