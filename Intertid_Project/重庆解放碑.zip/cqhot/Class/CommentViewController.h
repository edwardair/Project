//
//  CommentViewController.h
//  cqhot
//
//  Created by ZL on 13-4-17.
//  Copyright (c) 2013年 gitmac. All rights reserved.
//

#import "EUViewController.h"

@interface CommentViewController : EUViewController

@end
